package sh.radical.samplecar.entities;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class UserContext {

	public String userId;
}
