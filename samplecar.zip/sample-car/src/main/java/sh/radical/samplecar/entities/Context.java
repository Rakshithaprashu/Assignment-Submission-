package sh.radical.samplecar.entities;

import lombok.Getter;
import lombok.Setter;
import sh.radical.samplecar.entities.UserContext;

@Getter
@Setter
public class Context {

	public UserContext userContext;
}
