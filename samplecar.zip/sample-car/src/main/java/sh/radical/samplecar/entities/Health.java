package sh.radical.samplecar.entities;

import lombok.Data;

@Data
public class Health {

	String status = "up";
}
